"""Archive the fixed actuation comparison without changing its results."""

import hashlib
import json
import shutil
import zipfile
from pathlib import Path

import imageio.v2 as imageio
import matplotlib
import numpy as np
from PIL import Image, ImageDraw

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
ART = Path(__file__).resolve().parent
RUN = ART / "run"
VIDEOS = ROOT / "artifacts/actuation-improvement-videos"
EVIDENCE = ROOT / "evidence/actuation-improvement-2026-10-28"
HUMAN = ROOT.parent / "embodied-human"


def digest(path):
    return hashlib.file_digest(path.open("rb"), "sha256").hexdigest()


report = json.loads((RUN / "fullreport.json").read_text())
update = report["model_update"]
groups = sorted(report["partitions"]["test"])
metrics = ["speed_rmse_mps", "gap_rmse_m", "acceleration_rmse_mps2"]
labels = ["Speed RMSE (m/s)", "Gap RMSE (m)", "Acceleration RMSE (m/s²)"]
means = {}
fig, axes = plt.subplots(1, 4, figsize=(12, 4.5), layout="constrained")
for index, (metric, label) in enumerate(zip(metrics, labels)):
    values = np.array([[update["source_metric_errors"][role][g][metric]
                        for role in ("baseline", "fitted")] for g in groups])
    means[metric] = dict(zip(("baseline", "corrected"), values.mean(axis=0).tolist()))
    ax = axes[index]
    for row in values:
        ax.plot([0, 1], row, color="#8c959e", alpha=.45, linewidth=.8)
    ax.plot([0, 1], values.mean(axis=0), "o-", color="#155c9e", linewidth=2)
    ax.set_ylabel(label)
    ax.set_xticks([0, 1], ["Legacy", "Corrected"])
    ax.set_ylim(bottom=0)
    ax.grid(axis="y", alpha=.2)
values = np.array([[update["source_primary_errors"][role][g]["normalized_trajectory_mse"]
                    for role in ("baseline", "fitted")] for g in groups])
for row in values:
    axes[3].plot([0, 1], row, color="#8c959e", alpha=.45, linewidth=.8)
axes[3].plot([0, 1], values.mean(axis=0), "o-", color="#155c9e", linewidth=2)
axes[3].set_ylabel("Normalized trajectory MSE")
axes[3].set_xticks([0, 1], ["Legacy", "Corrected"])
axes[3].set_ylim(bottom=0)
axes[3].grid(axis="y", alpha=.2)
fig.suptitle("Fresh NGSIM test: 24 source tracks, two seeds per controller\n"
             "Grey: each source. Blue: mean. Primary change −0.0699, 95% CI [−0.1655, 0.0212].",
             fontsize=11)
fig.savefig(ART / "paired-source-errors.png", dpi=160)
plt.close(fig)

manifest = json.loads((VIDEOS / "manifest.json").read_text())
video_checks = []
posters = []
for group, row in manifest["trials"].items():
    for item in [row, *row["profiles"]]:
        path = VIDEOS / item["file"]
        assert digest(path) == item["sha256"]
        with imageio.get_reader(path) as reader:
            metadata = reader.get_meta_data()
            frames = reader.count_frames()
            assert frames == 500 and metadata["fps"] == 25
            size = tuple(metadata["size"])
            assert size == ((1920, 1080) if item is row else (960, 1080))
            if item is row:
                poster = Image.fromarray(reader.get_data(250))
                poster.save(VIDEOS / f"{group.replace(':', '_')}-poster.png")
                poster.thumbnail((960, 540))
                posters.append(poster)
        video_checks.append({"file": path.name, "frames": frames, "fps": 25,
                             "size": size, "sha256": item["sha256"]})
    assert all(all(value == 0 for value in p["maximum_absolute_replay_errors"].values())
               for p in row["profiles"])
with imageio.get_reader(VIDEOS / "held-out-trials.mp4") as reader:
    metadata = reader.get_meta_data()
    assert reader.count_frames() == 1000
    assert metadata["fps"] == 25 and tuple(metadata["size"]) == (1920, 1080)
assert digest(VIDEOS / "held-out-trials.mp4") == manifest["montage"]["sha256"]
contact = Image.new("RGB", (960, 1120), "white")
draw = ImageDraw.Draw(contact)
for i, poster in enumerate(posters):
    contact.paste(poster, (0, i * 560 + 20))
    draw.text((10, i * 560 + 3), list(manifest["trials"])[i], fill="black")
contact.save(ART / "trial-contact-sheet.png")
verification = {"status": "verified", "profiles_with_zero_replay_error": 4,
                "video_checks": video_checks, "montage_frames": 1000,
                "montage_seconds": 40, "montage_sha256": manifest["montage"]["sha256"],
                "selection": "first two fresh test source identifiers in sorted order",
                "base_seed": 117}
(ART / "video-verification.json").write_text(json.dumps(verification, indent=2) + "\n")
engineering = json.loads((ART / "acceleration-tracking.json").read_text())
summary = {"status": "evaluated", "decision": update["decision"],
           "defaults_updated": False, "test_used_for_retuning": False,
           "development_sources": 32, "test_sources": 24, "test_seeds": [117, 118],
           "complete_safe_episodes": 192, "selected_arm": report["selection"]["selected_arm"],
           "source_mean_errors": means,
           "mean_normalized_trajectory_mse": dict(zip(("baseline", "corrected"), values.mean(axis=0).tolist())),
           "paired_source_comparison": update["paired_source_comparison"],
           "engineering_mean_reference_grid_rmse_mps2": engineering["mean_reference_grid_tracking_rmse_mps2"],
           "engineering_scoring": engineering["reference_grid_scoring"],
           "fullreport_sha256": digest(RUN / "fullreport.json"),
           "source_revisions": {"myosuite_carla": "d545099dd1766c0f044cab74810620ff39e0381c",
                                "embodied_human": "e938e90b7d38638fe2c588e5e7f7a6621e41eec2",
                                "myosuite_dev": "37c8b863fe448f8fff2b29eb62a53a269b79d16f"},
           "limitations": report["limitations"] + [
               "The inverse controller and engineering benchmark use the same vehicle model.",
               "Longitudinal control receives exact simulated speed, gap, closing speed and acceleration.",
               "The design was fixed locally before simulation. Source commits were published during the test transition.",
               "No live CARLA validation was performed for this experiment."]}
EVIDENCE.mkdir(parents=True, exist_ok=True)
(EVIDENCE / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
for src, name in [(RUN / "experimental-profile.json", "experimental-profile.json"),
                  (ART / "paired-source-errors.png", "paired-source-errors.png"),
                  (ART / "trial-contact-sheet.png", "trial-contact-sheet.png"),
                  (ART / "video-verification.json", "video-verification.json"),
                  (VIDEOS / "manifest.json", "video-manifest.json")]:
    shutil.copy2(src, EVIDENCE / name)
attribution = {"dataset": "NGSIM I-80 vehicle trajectories", "source": "https://doi.org/10.21949/1504477",
               "licence": "CC BY-SA 3.0", "derived_fixtures": ["run/development.npz", "run/test.npz"],
               "processing": "Existing empirical NGSIM loader; 10 Hz signals with Savitzky-Golay smoothing (window 21, polynomial 3); fixed first 20 second source window.",
               "source_sha256": "bc3cff7ccc9c9fa5425f3424d5bee341dea2a35ea955328b3b221ee64c3931dc"}
(EVIDENCE / "data-attribution.json").write_text(json.dumps(attribution, indent=2) + "\n")
archive_files = {"run/" + p.relative_to(RUN).as_posix(): p for p in RUN.rglob("*") if p.is_file()}
for name in ("acceleration-tracking.json", "acceleration-tracking.txt", "bridge-tests.txt", "bridge-tests.xml",
             "human-tests.txt", "human-tests.xml", "bridge-build.txt", "human-build.txt", "video-verification.json",
             "package_evidence.py", "video-1136.txt", "video-1193.txt"):
    p = ART / name
    if p.is_file(): archive_files["checks/" + name] = p
archive_files["video/manifest.json"] = VIDEOS / "manifest.json"
archive_files["source/check_acceleration_tracking.py"] = ROOT / "examples/check_acceleration_tracking.py"
archive_files["source/record_empirical_trials.py"] = ROOT / "examples/record_empirical_trials.py"
archive_files["source/evaluate_actuation_improvement.py"] = HUMAN / "examples/evaluate_actuation_improvement.py"
archive_files["source/actuation_evaluation.py"] = HUMAN / "src/embodied_human/actuation_evaluation.py"
archive_files["inputs/component-report.json"] = ROOT / "evidence/empirical-driving-2026-10-28/ngsim.json"
archive_files["inputs/prior-closed-loop-report.json"] = ROOT / "artifacts/closed-loop-calibration-2026-10-28/run/fullreport.json"
archive_files["inputs/benchmark-report.json"] = ROOT / "artifacts/closed-loop-benchmark.json"
archive_files["data-attribution.json"] = EVIDENCE / "data-attribution.json"
commands = {
    "working_directory": "myosuite-carla repository root",
    "pythonpath_sources": ["../embodied-human/src", "../myosuite-dev-review"],
    "acceleration_tracking": ["python", "examples/check_acceleration_tracking.py", "--out",
                              "artifacts/actuation-improvement-2026-10-28/acceleration-tracking.json"],
    "study": ["python", "../embodied-human/examples/evaluate_actuation_improvement.py",
              "--source", "artifacts/ngsim/ngsim-i80-cars.csv", "--component-report",
              "evidence/empirical-driving-2026-10-28/ngsim.json", "--development-report",
              "evidence/empirical-driving-2026-10-28/ngsim.json", "--development-report",
              "artifacts/closed-loop-calibration-2026-10-28/run/fullreport.json", "--development-report",
              "artifacts/closed-loop-benchmark.json", "--out", "artifacts/actuation-improvement-2026-10-28/run",
              "--development-sources", "32", "--test-sources", "24", "--seed", "20261029",
              "--development-seed", "17", "--test-seeds", "117", "118", "--seconds", "20",
              "--desired-speed", "16", "--bootstrap", "5000", "--workers", "3"],
    "video": ["python", "examples/record_empirical_trials.py", "--source", "artifacts/ngsim/ngsim-i80-cars.csv",
              "--report", "artifacts/actuation-improvement-2026-10-28/run/fullreport.json", "--out",
              "artifacts/actuation-improvement-videos", "--groups", "ngsim:1136:2", "ngsim:1193:2",
              "--base-seed", "117"],
    "reference_grid_note": "The common reference grid metric was computed from the retained 18 trial traces after execution. The current tracking example computes this metric during postprocessing. No physical traces were changed.",
    "checks": [["python", "-m", "pytest", "tests", "-q"],
               ["python", "-m", "pytest", "../embodied-human/tests", "-q"],
               ["python", "-m", "ruff", "check", "src", "tests", "examples"],
               ["python", "-m", "mypy", "src/myosuite_carla", "--ignore-missing-imports", "--follow-imports=skip"],
               ["python", "-m", "build"]],
}
(ART / "commands.json").write_text(json.dumps(commands, indent=2) + "\n")
archive_files["commands.json"] = ART / "commands.json"
checksums = {name: {"sha256": digest(p), "bytes": p.stat().st_size} for name,p in archive_files.items()}
with zipfile.ZipFile(EVIDENCE / "study-evidence.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for name, p in sorted(archive_files.items()): archive.write(p, name)
    archive.writestr("manifest.json", json.dumps(checksums, indent=2) + "\n")
with zipfile.ZipFile(EVIDENCE / "study-evidence.zip") as archive:
    assert archive.testzip() is None
    for name, check in checksums.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == check["sha256"]
dest = HUMAN / "evidence/actuation-improvement-2026-10-28"
dest.mkdir(parents=True, exist_ok=True)
for p in EVIDENCE.iterdir():
    if p.is_file(): shutil.copy2(p, dest / p.name)
print(json.dumps({"evidence_archive_bytes": (EVIDENCE / "study-evidence.zip").stat().st_size,
                  "archive_files": len(checksums), "test_sources": len(groups),
                  "video_verification": verification["status"], "summary": str(EVIDENCE / "summary.json")}, indent=2))
