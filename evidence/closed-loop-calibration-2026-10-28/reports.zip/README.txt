The physical calibration completed 141 episodes safely. The selected candidate increased held out normalized trajectory MSE. It was rejected. Global defaults remain unchanged.
The fixed design was written before fitting and published in source commits cbb05bf and c09b2cf before the test stage.
NGSIM source metadata records CC BY-SA 3.0. The source DOI is https://doi.org/10.21949/1504477. Source data attribution and licensing remain associated with derived trajectory measurements. Original package code retains its repository licence.
Bulk datasets are excluded. The input source SHA256 is retained in provenance.json. Command paths identify the actual Windows workspace. Adjust paths for another checkout.
